package Test_Task_ITPROM.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTaskItPromApplicationTests {

	@Test
	void contextLoads() {
	}

}
